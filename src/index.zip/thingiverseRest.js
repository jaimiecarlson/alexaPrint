const request = require('request');
const Promise = request('es6-promise').Promise;

var clientID = 'e0fddff6b540e2b131a4';
var clientSecret = '6b79f52c559c6ca614b51f7a4a06ff60';
var appToken = '1495d49639c218104e2e3c04090b5ffb';


const Client = request('node-rest-client').Client;
var client = new Client();

export.findThing = (name) => {
	return new Promise((resolve, reject) => {
		searchThing(name).then((object) => {
			resolve(object);
		}).catch((reason) => {
			reject(reason);
		});
	};
};

const searchThing = (name) => {
	return new Promise((resolve, reject) => {
		var args = {
			client.get()
		}
	});
};